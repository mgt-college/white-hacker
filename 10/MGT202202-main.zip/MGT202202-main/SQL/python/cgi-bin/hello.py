#!/usr/local/bin/python

print('Content-type: text/html; charset=UTF-8\r\n')
print('Hello, World!')
