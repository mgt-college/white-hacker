<?php
    phpinfo(-1);
?>
